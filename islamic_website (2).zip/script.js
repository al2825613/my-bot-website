document.addEventListener("DOMContentLoaded", function() {
    alert("مرحبًا بك في الموقع الإسلامي!");
});